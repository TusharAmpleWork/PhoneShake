import React from "react";
import { Text, View,Dimensions } from 'react-native';
import { moderateScale, scale } from "react-native-size-matters";
import styles from "./style";
import  Icon  from "react-native-vector-icons/AntDesign";
import  Icon2  from "react-native-vector-icons/EvilIcons";
import  Icon3  from "react-native-vector-icons/AntDesign";

const{height,width}=Dimensions.get('window')
const Heading=({title,headStyle})=>{
    return(
        <View style={[styles.headText,headStyle]}>
            <Text style={[styles.headText,headStyle]}>{title}</Text>
        </View>
    )
}
const SubHeading=({title,sectionStyle,onPress})=>{
    return(
        <View>
    <Text style={styles.section} onPress={onPress} >{title}</Text>
</View>
    )
}
const SubSection=({text,name,icon,iconStyle})=>{
    return(
        <View style={[styles.subSection]}>
    <Text style={[styles.subSectionTitle]}>{text}</Text>
    <View style={[styles.subSectionView]} >
    <Text style={[styles.subText]}>{name}</Text>
  <Icon name={'right'} style={[styles.icon,iconStyle]} />
    </View>
</View>
    )
}
const Icons=({icon,icon2,icon3})=>{
    return(
        <View style={styles.subIcon}>
<Icon name={icon}  style={{fontSize:scale(16),color:'#A8A8A8',}} />
<Icon2 name={icon2}  style={{fontSize:scale(16),color:'#A8A8A8'}}/>
<Icon3 name={icon3}  style={{fontSize:scale(16),color:'#A8A8A8'}} />
        </View>
    )
}


export {Heading,SubHeading,SubSection,Icons};