import { StyleSheet,Dimensions } from "react-native";
import {verticalScale,scale,moderateScale, ScaledSheet,vs, s} from 'react-native-size-matters'
const{height,width}=Dimensions.get('window')

const styles=ScaledSheet.create({
   Primarybtn:{

    height:scale(45),
    width:scale(285),
    backgroundColor:'#208EFB',
    alignItems:'center',
    justifyContent:'center',
    marginTop:scale(101),
    borderRadius:scale(5),
    //marginBottom:scale(10),
  
   },
   BtnTitle:{
    fontSize:vs(16),
    textAlign:'center',
    //margin:vs(12),
    letterSpacing:moderateScale(0.02),
   //  lineHeight:moderateScale(19),
    color:'#ffffff',
   //  padding:moderateScale(11),
    fontWeight:'bold'
   },
   t11:{
      fontSize:scale(16),
      textAlign:'center',
      margin:scale(10),
      letterSpacing:moderateScale(0.02),
      lineHeight:moderateScale(19),
      color:'#ffffff',
      padding:moderateScale(8)
     },
   Secondarybtn:{
      fontSize:scale(14),
          color:'#208efb',
          textAlign:'center',
          marginTop:1,
      height:verticalScale(36),
      //width:"100%",
      alignItems:'center',
      justifyContent:'center'
      //marginLeft:scale(45)
   },
   emailbtnText:{
      fontSize:scale(14),
      color:'#208efb',
      textAlign:'center',
     height:verticalScale(20),
     width:scale(250),
     //marginLeft:scale(45),
   },
   checkbtn:{
      fontSize:scale(16),
      //lineHeight:scale(19),
      color:'#ffffff',
      textAlign:'center',
      backgroundColor:'#208EFB',
      height:scale(45),
      width:scale(285),
      //marginRight:scale(40),
      //marginLeft:scale(30),
      borderRadius:scale(5),
      //padding:moderateScale(10),
      marginTop:scale(30),
      fontWeight:'500'
   },
   topbtn:{
backgroundColor:'#208EFB',
height:29,
width:29,
justifyContent:'center',
alignItems:'center',
borderRadius:5,
marginRight:scale(12)
   },
   btnview:{
      width:'100%',
    height:height/8,
      justifyContent:'center',
      alignItems:'flex-end',
      backgroundColor:'#FFFFFF',
     
     
   },
   numb:{
      
      color:'#FFFFFF',
      //textAlign:'center',
       justifyContent:'center',
       alignItems:'center',
     fontSize:12,
     fontWeight:'800',
    
     
     
    
   }

})

export default styles;