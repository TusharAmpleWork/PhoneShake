import React ,{useState,useEffect}from "react";
import {  KeyboardAvoidingView, Text,TouchableOpacity, View,Image } from'react-native'
import  styles  from "./style";
import { scale } from "react-native-size-matters";
    const LoadBtn=({onPress,title,textStyle,disabled})=>{
      
        return(
            <View style={{justifyContent:'center',alignItems:'center'}}>
            <TouchableOpacity style={[styles.Primarybtn,textStyle]}
             activeOpacity={0.6} onPress={onPress} disabled={disabled} >
                <Text style={styles.BtnTitle} >{title}</Text>
            </TouchableOpacity>
            </View>
        )
    }
    const LoginBtn=({onPress,title,textStyle,innerTextStyle})=>{
        return(
            <View>
                <TouchableOpacity onPress={onPress} style={[textStyle]}>
                    <Text style={[styles.Secondarybtn,innerTextStyle]}>{title}  </Text>
                </TouchableOpacity>
            </View>
        )
    }
    const EmailBtn=({onPress,title,textStyle,disabled})=>{
        return(
<View>
  
                <TouchableOpacity onPress={onPress}  >
<Text style={[styles.emailbtnText,textStyle]}>{title}</Text>
                </TouchableOpacity>
            
            </View>
        )
    }
    const CheckBtn=({onPress,title,textStyle,txtStyle})=>{
        return(
            <View style={textStyle}>
                <TouchableOpacity onPress={onPress}
                style={[styles.checkbtn,textStyle]}
                >
                    <Text style={txtStyle}>{title}</Text>
                </TouchableOpacity>
            </View>
        )
    }//textStyle={textStyle}

    const AvlbBtn=({number,onPress})=>{
        return(
            <View style={styles.btnview}>
                <TouchableOpacity onPress={onPress}
                style={styles.topbtn}
                activeOpacity={0.7}
                >
                    <Text style={styles.numb}>{number}</Text>
                </TouchableOpacity>
            </View>
        )
    }
   const SocialMediabtn=({image,text,onPress})=>{
    return(
        <View style={{height:70,width:70,marginRight:scale(20),marginBottom:scale(35)}} >
    <View style={{height:scale(65),
      width:scale(65),
      backgroundColor:"#F7F7F7",
      marginRight:scale(20),justifyContent:'center', marginBottom:scale(10),alignItems:'center'}}>

  <TouchableOpacity onPress={onPress} >

  <Image source={image}
 style={{width:scale(30),height:scale(30)}}
  resizeMode="contain"
  />
  </TouchableOpacity>
  </View>
  <Text style={{marginBottom:scale(6),fontSize:scale(9),fontWeight:'500',color:'#7F7F7F',textAlign:'center'}} >{text}</Text>
  </View>
    )
   }
  


export { LoadBtn,LoginBtn,EmailBtn,CheckBtn,AvlbBtn,SocialMediabtn};