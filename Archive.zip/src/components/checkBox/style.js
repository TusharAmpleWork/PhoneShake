import { StyleSheet } from 'react-native';
import { } from 'react-native-size-matters'
const styles=StyleSheet.create({
    check1:{marginTop:12,
height:10,
width:20,
marginRight:15
}
})

export default styles;