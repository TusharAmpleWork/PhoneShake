import React, { useEffect, useState } from "react";
import { TextInput, View} from 'react-native';

import styles from "./style";
const Tinput=({placeholder,onChangeText,inputStyle,defaultValue})=>{
    
    return(
        <View>
            <TextInput style={[styles.Tin,inputStyle]}
            placeholder={placeholder}
            onChangeText={onChangeText}
            defaultValue={defaultValue}
            />
</View>
    )
}
export default Tinput;