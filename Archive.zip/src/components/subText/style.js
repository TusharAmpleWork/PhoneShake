import { StyleSheet } from 'react-native';
import { moderateScale, scale, ScaledSheet } from 'react-native-size-matters';
const styles=ScaledSheet.create({
subT:{
     fontSize:scale(12),
     color:'#A8A8A8',
    // height:moderateScale(17),
    // width:"100%",
   
    // marginLeft:scale(80),
    marginTop:scale(7)
}
})
export default styles;