import React from "react";
import { Text, View } from 'react-native'
import styles from "./style";

const SubHead=({title,subStyle})=>{
    return(
        <View style={{justifyContent:"center",alignItems:'center'}}>
            <Text style={[styles.subT,subStyle]} >{title}</Text>
        </View>
    )
}
export default SubHead;
