import React, {useEffect, useState} from 'react';
import {View, Text, TextInput} from 'react-native';
import styles from './style';
import {LoadBtn, LoginBtn} from '../../components/button' ;
import { Heading } from '../../components/text';
import { SubHeading } from '../../components/text';



const MobileVerf = ({navigation}) => {


  const [state, setState] = useState({
    number: '',
    // btnColor: false,
    // txtColor: false,
  });
const handleChange=(value)=>{
  setState(prevState=>({
    ...prevState,number:value
  }))
}

  const goToConfmCode = () => navigation.navigate('ConfirmCode');

  return (
    <View style={styles.mainView}>
      <Heading title={"What's your"} />
      <Heading title={"mobile number?"}
      headStyle={{marginTop:0}}
      />
      {/* <Text style={styles.mainText}>{"What's your mobile number?"}</Text> */}
      <SubHeading title={'Use email instead'} 
      onPress={() => navigation.navigate('EmailVerf')}
      /> 
      {/* <LoginBtn
      textStyle={styles.emailText}
        title={'Use email instead'}
        innerTextStyle={styles.emailLink}
        onPress={() => navigation.navigate('EmailVerf')}
        /> */}
     <View style={styles.countryCode}>
      <Text style={styles.numberInput}>IND+91</Text>
      <TextInput
    value={state.number}
          style={styles.MobileNumber}
          placeholder="Mobile Number"
          keyboardType="phone-pad"
           //onChangeText={x => setNumber(x)}
          onChangeText={handleChange}
        />
   </View>
      <Text style={styles.belowTextInput}>
        {"we'll send you an SMS verification code"}
      </Text>
      <LoadBtn
        title="Continue"
        onPress={goToConfmCode}
         //disabled={state.number.length===0?true:false}
        //disabled={state.number.trim().length>0?false:true}
        disabled={ state.number.trim().length>0?false:true}
//disabled={isDisabled}
  
textStyle={state.number.trim().length>0?styles.finalStateColor:styles.initialStateColor}
      />
    </View>
  );
}

export default MobileVerf;
