import React,{useState,useEffect} from "react";
import { View} from 'react-native'
import { LoadBtn } from "../../components/button";
import SubHead from "../../components/subText";
import { Heading } from "../../components/text";
import Tinput from "../../components/textInput";
import styles from "./style";
const OrgCheck=({navigation})=>{
    const goToPostn=()=>{
        navigation.navigate('Postn')
    }
    const[name,setName]=useState('')
    const[btn,setBtn]=useState(false)
    useEffect(()=>{
        if(name!==''){
            setBtn(true);
        }else{
            setBtn(false)
        }
    },[name])
return(
    <View style={styles.onBoardView}>
        <View style={{alignItems:'center',justifyContent:'center'}}>
<Heading title="What's your" headStyle={styles.firstTitle}/>
<Heading title="current organization" headStyle={styles.secondTitle} />   
</View>
<Tinput placeholder='Organization Name' onChangeText={(val)=>setName(val)}/>
<SubHead title={'Add your company/organization name'} />
<LoadBtn title='Continue' onPress={goToPostn} textStyle={btn?styles.initialColor:styles.finalColor}/>
    </View>
)
}

export default OrgCheck;