import React from "react";
import { Text, View } from "react-native";
import AnimatedEllipsis from 'react-native-animated-ellipsis';
const Loading=({navigation})=>{
    setTimeout(()=>{
navigation.navigate('person')
    },3000)
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center',marginBottom:60}}>
           <View style={{justifyContent:'center',alignItems:'center'}} >
            <AnimatedEllipsis style={{fontSize:80,color:'#208EFB'}} />
            </View>

            <Text style={{fontSize:24,color:'#208EFB'}}>{"We are getting your"}</Text>
            <Text style={{fontSize:24,textAlign:'center',color:'#208EFB'}}>{"account ready..."}</Text>
           
        </View>
    )
}
export default Loading;