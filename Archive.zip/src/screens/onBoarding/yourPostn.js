import React, { useState, useEffect } from "react";
import { Text, View } from 'react-native'
import { Heading } from "../../components/text";
import Tinput from "../../components/textInput";
import styles from "./style";
import { LoadBtn } from "../../components/button";
import SubHead from "../../components/subText";

const Postn = ({navigation}) => {
    const goPrivacy=()=>{
    navigation.navigate('Privacy')
    }
    const [name, setName] = useState('')
    const [btn, setBtn] = useState(false)
    useEffect(() => {
        if (name !== '') {
            setBtn(true);
        } else {
            setBtn(false)
        }
    }, [name])
    return (
        <View style={styles.onBoardView}>
            <View style={{justifyContent:'center',alignItems:'center'}} >
            <Heading title="Choose a @Handle,"
                headStyle={styles.primaryTitle} />
            <Heading title="your unique name for sharing"
                headStyle={styles.secondaryTitle} />
            <Heading title="your contact with anyone"
                headStyle={styles.thirdTitle} />
                </View>
            <Tinput placeholder={"@Handle"}
                onChangeText={(val) => setName(val)} />
                <SubHead title={"phoneshake.me/@"} />
            <LoadBtn title='Continue'
                textStyle={btn ? styles.initialColor : styles.finalColor} 
                onPress={goPrivacy}
                />

        </View>
    )
}

export default Postn;
