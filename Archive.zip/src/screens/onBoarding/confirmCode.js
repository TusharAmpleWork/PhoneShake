import React, { useEffect, useState } from "react";
import { Text, View,TextInput } from "react-native";
import { scale } from "react-native-size-matters";
import { LoginBtn ,LoadBtn, CheckBtn} from "../../components/button";
import styles from "./style";

const ConfirmCode=({navigation})=>{
    const Onboard=()=>{
    navigation.navigate("NameCheck")          
    }
    const [state, setState] = useState({
        number: '',
        show:true,
        // btnColor: false,
         txtColor: false,
      });
      const handleChange=(value)=>{
        setState(prevState=>({
          ...prevState,number:value
        }))
      }
  
return(
        <View style={styles.wholepage}>
            <View style={{justifyContent:'center',alignItems:'center',marginTop:scale(80)}}>
       <Text style={styles.MainCnfmHead}>{"Please enter"}</Text>
       <Text style={styles.MainCnfmHead}>{'the confirmation code'}</Text>
       </View>
       <LoginBtn title={'Did not recieve code'}
       innerTextStyle={styles.cnfmBtn}
       />
      
       <TextInput placeholder="Enter Code" 
       onChangeText={handleChange}
       keyboardType="phone-pad"
style={state.txtColor?styles.InputInitialColor:styles.InputFinalColor}
/>
<View style={styles.InputBorder} ></View>
{
 state.show?<Text style={styles.InputMiniText}>
    {"Enter the confirmation code sent to you"}
    </Text>:<Text style={styles.Ttext2}>
        {'The code entered is incorrect'}</Text>}
<LoadBtn title={'Continue'}
 onPress={Onboard}
 disabled={state.number.trim().length>0?false:true}
  //textStyle={btnColor?styles.btnload:styles.btnload2}
  textStyle={state.number.trim().length>0?styles.finalStateColor:styles.initialStateColor}
  />
</View>
    )
}
export default ConfirmCode;