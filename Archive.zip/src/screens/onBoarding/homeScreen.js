import React from 'react';
import {Image, Text, View} from 'react-native';
import styles from './style';
import {LoadBtn} from '../../components/button';

const HomePage = ({navigation}) => {
  const goToMobileVerif = () => navigation.navigate('MobileVerification');

  return (
    <View style={styles.wholepage}>
      <Image
        style={styles.logo}
        source={require('../../assets/images/logoS1.png')}
      />
      <View style={styles.mainHeading}>
        <Text style={styles.heading}>{'Welcome to '}</Text>
        <Text style={styles.heading}>{'Phoneshake'}</Text>
      </View>
      <View style={styles.login}>
        <LoadBtn
          title="Get Started"
          textStyle={styles.landingBtn}
          onPress={goToMobileVerif}
        />
        <View style={styles.textMargin}>
          <Text style={styles.btnSubHead}>{'Phoneshake for businesses'}</Text>
        </View>
      </View>
    </View>
  );
};

export default HomePage;
