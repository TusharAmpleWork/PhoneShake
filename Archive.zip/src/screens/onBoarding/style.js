import React from 'react';
import {StyleSheet, View,Dimensions} from 'react-native';
import {
  verticalScale,
  scale,
  moderateScale,
  ScaledSheet,
} from 'react-native-size-matters';
const {height,width}=Dimensions.get('window')
const styles = ScaledSheet.create({
  wholepage: {
    flex:1,
    backgroundColor: '#FFFFFF',
  
  },
  mainHeading:{
    alignItems:'center',
    justifyContent:'center'
  },
  heading:{
    fontSize:30
  },
  login:{
    justifyContent:"flex-end",
    flex:0.9
  },
  textMargin:{
    marginTop:16
  },
  logo: {
    height: verticalScale(120),
    width: scale(130),
    marginTop: moderateScale(130),
    marginLeft: moderateScale(125),
    marginRight: moderateScale(127),
  },
  mainHead: {
    height: verticalScale(180),
    width: scale(180),
    // marginLeft: scale(80),
    // marginRight: scale(49),
    fontSize: verticalScale(30),
    textAlign: 'center',
    justifyContent:'center',
    alignItems:'center',
    marginTop: scale(18),
    color: '#000000',
  },
  landingBtn:{
    justifyContent:'center',
     height:scale(55),
    width:verticalScale(250),
    backgroundColor:'#208EFB',
    marginTop:scale(70),
    borderRadius:scale(5),
    marginLeft:scale(45),
    marginRight:scale(45),
    marginBottom:scale(0),
  },

  btnSubHead: {
    backgroundColor: '#FFFFFF',
    textAlign: 'center',
    // marginBottom: scale(70),
    // marginTop: scale(26),
    fontSize: scale(14),
    //lineHeight: scale(16),
    color: '#208efb',
    fontWeight:'400'
  },
  mainView:{
    flex:1,
    backgroundColor: '#FFFFFF',

},
  mainText: {
    fontSize: scale(20),
    textAlign: 'center',
    marginTop: scale(80),
    marginLeft: scale(100),
    height: verticalScale(54),
    width: scale(148),
    fontWeight:'500',
    
  },
  emailText:{
    marginTop:scale(13),
    
fontWeight:'500'

  },
  countryCode:{
    flexDirection:'row',
    justifyContent:'center',
    borderBottomWidth:1,
    marginHorizontal:40,
    borderColor:'#00000033',
    marginTop:scale(65),
    marginBottom:10
  },
  numberInput:{
    marginTop:scale(6),
    height:verticalScale(21),
    width:scale(80),
    color:'#208EFB',
    fontSize:scale(17),
  }
  ,
  t4: {
    fontSize: scale(64),
    backgroundColor: '#208efb',
    textAlign: 'center',
    marginTop: scale(1),
    marginBottom: scale(40),
  },
  t5: {
    fontSize: scale(18),
    textAlign: 'left',
    marginLeft: scale(90),
    marginTop: scale(100),
    borderBottomWidth: scale(22),
  },
  t6: {
    height: scale(90),
    width: scale(90),
    marginLeft: scale(45),
    flexDirection: 'row',
  },
  t7: {
    marginTop: scale(1),
    height: verticalScale(37),
    width: scale(300),
  },
  MobileNumber: {
    marginTop: scale(0),
    height: verticalScale(38),
    width: scale(150),
    marginLeft:scale(3),
    fontSize:scale(16),
    fontWeight:'500',
    color:'#000000',
   
  },
  subView: {
    borderBottomWidth: scale(1),
    height: verticalScale(40),
    marginLeft: scale(45),
    marginRight: scale(60),
    marginTop: scale(1),
    borderColor: '#00000033',
  },
  initialStateColor: {
    backgroundColor: '#208efb80',
    fontWeight:'bold',
   marginTop:45
  },
  finalStateColor: {
    backgroundColor: '#208efb',
    fontWeight:'bold',
    marginTop:45
//#208efb80
  },
  emailView: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  emailHeading: {
    height: scale(40),
    width: scale(169),
    marginTop: scale(80),
    justifyContent:'center',
    alignItems:'center',
    // marginLeft: scale(90),
    fontSize: scale(20),
    fontWeight:'500'
  },
  Tinput: {
    marginLeft: scale(125),
    fontSize: scale(15),
    color: '#7F7F7F',
    marginTop: scale(0),
  },
  Tinput1: {
    marginLeft: scale(125),
    fontSize: scale(15),
    color: '#000000',
    marginTop: scale(0),
  },
  Tview: {
    borderBottomWidth: scale(1),
    marginLeft: scale(30),
    marginRight: scale(40),
    marginTop: scale(6),
    borderColor: '#00000033',
  },
  belowTextInput: {
    marginTop: scale(1),
    fontSize: scale(12),
    marginLeft: scale(70),
    color: '#A8A8A8',
    height:scale(44),
    fontWeight:'500',
    width:scale(400)
   
  },
  emailSubText:{
    marginTop: scale(10),
    fontSize: scale(12),
    marginLeft: scale(70),
    color: '#A8A8A8',
    height:scale(44),
    fontWeight:'500',
    width:scale(400)
  },
  InputInitialColor: {
    marginLeft: scale(145),
    fontSize: scale(15),
    color: '#7F7F7F',
    marginTop: scale(60),
    fontWeight:'500',
    
  },
  InputFinalColor: {
    marginLeft: scale(145),
    fontSize: scale(15),
    color: '#000000',
    marginTop: scale(50),
    fontWeight:'500',
   
  },
  CodeView:{
    flex:1,
    backgroundColor: '#FFFFFF',

  },
  MainCnfmHead: {
    height: scale(20),
    // width:"100%",
    //marginTop: scale(80),
    // marginLeft: scale(135),
    // marginRight: scale(100),
    // alignItems:'center',
    // justifyContent:"center",
    fontSize: scale(20),
    lineHeight: scale(24),
    fontWeight:'500'
  },
  CnfmHead: {
    height: scale(25),
    //width: "100%",
    //marginLeft: scale(85),
    //marginRight: scale(100),
    fontSize: scale(20),
    lineHeight: scale(24),
    fontWeight:'500'
  },
  cnfmBtn:{
textAlign:'center',
//marginLeft:65,
marginTop:20,
fontWeight:'500'
  },
  emailLink:{
    fontWeight:'500',
    
  },
  InputBorder: {
    borderBottomWidth: scale(1),
    // marginLeft: scale(55),
    // marginRight: scale(50),
    marginTop: scale(6),
    borderColor: '#00000033',
    marginHorizontal:40
  },
  InputMiniText: {
    marginTop: scale(20),
    fontSize: scale(12),
    marginLeft: scale(70),
    color: '#A8A8A8',
    fontWeight:'500',
    
  },
  Ttext2: {
    marginTop: scale(7),
    fontSize: scale(12),
    marginLeft: verticalScale(100),
    color: '#F33C57',
  },
  dummy: {
    backgroundColor: 'black',
  },
  startbtn:{
    fontWeight:'300'
  },
  emailbtn:{
 
  },
  onBoardView:{
    flex:1,backgroundColor: '#FFFFFF'
 },
 initialColor:{
      backgroundColor:'#208efb'
  },
  finalColor:{
      backgroundColor:'#208efb80'
  },
  titleHead:{
      height:scale(48),
      width:scale(160),
      marginTop:scale(80),
      fontSize:scale(19),
      marginRight:scale(1),
      marginLeft:scale(104),
      fontWeight:'500'
  },
  firstTitle:{
      fontSize:scale(20),
      height:scale(23),
      width:"100%",
      marginTop:scale(74),
    //   marginRight:scale(87),
    //   marginLeft:scale(130),
    alignItems:"center",
    justifyContent:'center',
      fontWeight:'500'
  },
  secondTitle:{
      marginTop:scale(0),
      fontWeight:'500',
      alignItems:"center",
      justifyContent:'center',
      width:"100%",
     },
     primaryTitle:{
      height:scale(25),
      width:"100%",
      //marginLeft:scale(90)
      //justifyContent:'center',
    
      fontWeight:'500'
     },
     secondaryTitle:{
      width:"100%",
      height:scale(25),
      //marginLeft:scale(51),
      marginTop:scale(0),
      //marginRight:scale(50),
      fontWeight:'500'
     },
     thirdTitle:{
       width:"100%",
      //marginLeft:scale(70),
      marginTop:scale(0),
      //marginRight:scale(50),
      fontWeight:'500'
     },
     PrivacyTitle:{
      fontSize:scale(20),
      height:scale(24),
      width:"100%",
     
    //   justifyContent:'center',
    //   alignItems:'center',
      marginTop:scale(30),
    //   marginRight:scale(124),
    //   marginLeft:scale(124)
     },
     SubHeadingFirst:{
      fontSize:scale(12),
      height:moderateScale(14),
      width:'90%',
      flexDirection:"column",
      color:'#7F7F7F',
      fontWeight:'500'
    //   marginLeft:scale(12),
    //   marginRight:scale(12),

     },
     SubText:{
      fontSize:scale(14),
      height:moderateScale(330),
      width:scale(299),
    color:"#000000",
      marginTop:scale(6),
   marginLeft:scale(18),
 

   },
   pview:{
      height:moderateScale(50),
      width:scale(250),
      flexDirection:'row'
   },
   ptext:{
    margin:7,
    color:'#000000'
   },
   ptext2:{
      margin:7,
     
     },
   subview:{
      marginTop:scale(18),
      marginLeft:scale(35)
   },
//      prvbtn:{
//         backgroundColor:'green',
//         height:scale(50),
//     width:verticalScale(285),
//    backgroundColor:'#20AFFB',
//    marginTop:scale(40),
//    borderRadius:scale(5),
//    marginLeft:scale(0),
//    marginRight:scale(100),
//    marginBottom:scale(3)
//          },
       new:{
marginTop:30
       },
       new1:{
          marginTop:30,
          backgroundColor:'#208efb80'
       },
       PT1:{
          color:'#208efb'
       },
       PT11:{
          color:'#208efb80'
       },
       Readyhead:{
      height:scale(58),
       width:scale(212),
       marginTop:scale(310),
       fontSize:scale(24),
       marginRight:scale(1),
       marginLeft:scale(82)
      }
});

export default styles;
