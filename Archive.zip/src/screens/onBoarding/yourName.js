import React, { useEffect, useState } from "react";
import { View } from 'react-native';
import { LoadBtn } from "../../components/button";
import SubHead from "../../components/subText";
import { Heading } from "../../components/text";
import Tinput from "../../components/textInput";
import styles from "./style";
const NameCheck=({navigation})=>{
    const[name,setName]=useState('')
    const[btn,setBtn]=useState(false)
    useEffect(()=>{
        if(name!==''){
            setBtn(true);
        }else{
            setBtn(false)
        }
    },[name])
    const goToOrg=()=>{
navigation.navigate('OrgCheck')
    }
    return(
        <View style={styles.onBoardView}>
            <Heading title={"What's your name"} headStyle={styles.titleHead}/>
            <Tinput placeholder={'Full Name'} onChangeText={(val)=>setName(val)}/>
            <SubHead title={'Add your first and last name'}  />
            <LoadBtn title='Continue' onPress={goToOrg} textStyle={btn?styles.initialColor:styles.finalColor} />
        </View>
    )
}

export default NameCheck;