import { NavigationContainer } from "@react-navigation/native";
import React ,{useState,useEffect}from "react";
import { View,Text, KeyboardAvoidingView} from 'react-native';
import { EmailBtn, LoadBtn, LoginBtn } from "../../components/button";
import { Heading, SubHeading } from "../../components/text";
import Tinput from "../../components/textInput";
import styles from "./style";
const EmailVerf=({navigation})=>{
    const [state, setState] = useState({
        number: '',
        // btnColor: false,
        // txtColor: false,
      });
 
    const goToMobileVerf=()=>{
        navigation.navigate('MobileVerification') 
        }
    const goToConfmCode=()=>{
        navigation.navigate('ConfirmCode')
    }  
    const handleChange=(value)=>{
        setState(prevState=>({
          ...prevState,number:value
        }))
      }  
    return(
      
        <View style={styles.emailView}>
             <View style={{justifyContent:'center',alignItems:'center'}}>
              <Heading title={"What's your email?"} />
{/* <Text style={styles.emailHeading}>{"What's your email?"}</Text>
<EmailBtn title='Use phone instead'
onPress={goToMobileVerf}
textStyle={styles.emailbtn}
/> */}
<SubHeading title={'Use phone instead'} 
      onPress={goToMobileVerf}/>
</View>
<View style={{marginTop:0}}>
<Tinput placeholder="Email Address" 
InputStyle={state.number.trim().length>0?styles.Tinput:styles.Tinput1}
onChangeText={handleChange}
/>

<Text style={styles.emailSubText}>{"we'll send you an EMAIL verification code"}</Text>
</View>
<LoadBtn title={'Continue'} 
onPress={goToConfmCode}
disabled={state.number.trim().length>0?false:true}
textStyle={state.number.trim().length>0?styles.finalStateColor:styles.initialStateColor}  />

 </View>
      
    )
}
export default EmailVerf;