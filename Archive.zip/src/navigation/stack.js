import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import {createStackNavigator} from '@react-navigation/stack';
import MobileVerf from "../screens/onBoarding/mobileVerif";
import EmailVerf from "../screens/onBoarding/emailVerif";
import ConfirmCode from "../screens/onBoarding/confirmCode";
import NameCheck from "../screens/onBoarding/yourName";
import OrgCheck from "../screens/onBoarding/yourOrg";
import Postn from "../screens/onBoarding/yourPostn";
import Privacyp from "../screens/onBoarding/privacyPolicy";
import Loading from "../screens/onBoarding/loadingPage";
import HomePage from "../screens/onBoarding/homeScreen";

const Stack=createStackNavigator();
const HomeStack=()=>{
    return(
<NavigationContainer>
    <Stack.Navigator screenOptions={{headerShown:false }} >
<Stack.Screen name='landing' component={HomePage} />
<Stack.Screen name="MobileVerification" component={MobileVerf} />
<Stack.Screen name="EmailVerf" component={EmailVerf} />
<Stack.Screen name="ConfirmCode" component={ConfirmCode} />
<Stack.Screen name="NameCheck" component={NameCheck} />
<Stack.Screen name="OrgCheck" component={OrgCheck} />
<Stack.Screen name="Postn" component={Postn} />
<Stack.Screen name="Privacy" component={Privacyp} />
<Stack.Screen name="Loading" component={Loading} />
    </Stack.Navigator>
</NavigationContainer>
    )
}

export default HomeStack;